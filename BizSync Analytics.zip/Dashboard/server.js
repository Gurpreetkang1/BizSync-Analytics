// server.js

const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const { Parser } = require('json2csv'); 
const path = require('path'); 

const app = express();
const PORT = 5001;
const BASE_API_PATH = '/api';


const db = mysql.createPool({
    host: 'localhost',
    user: 'root', 
    password: 'password',  
    database: 'analytics_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// --- Middleware ---
app.use(cors()); 
app.use(express.json());

// =========================================================================
//                             HTML SERVING CONFIGURATION
// =========================================================================

// 1. Serve static files (CSS, JS, images, etc.) from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// 2. Handle the root URL ('/') request by sending the index.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// =========================================================================
//                             UTILITY FUNCTIONS
// =========================================================================

/**
 * Converts frontend filters (query parameters) into a SQL WHERE clause.
 */
function buildFilter(query) {
    const filters = [];
    const values = [];

    if (query.region && query.region !== 'All') {
        filters.push('region = ?');
        values.push(query.region);
    }
    if (query.product && query.product !== 'All') {
        filters.push('product_name = ?');
        values.push(query.product);
    }
    if (query.channel && query.channel !== 'All') {
        filters.push('sales_channel = ?');
        values.push(query.channel);
    }
    if (query.category && query.category !== 'All') {
        filters.push('product_category = ?');
        values.push(query.category);
    }
    if (query.start_date) {
        filters.push('order_date >= ?');
        values.push(query.start_date);
    }
    if (query.end_date) {
        filters.push('order_date <= ?');
        values.push(query.end_date);
    }
    // Handle 'tier' drill-down filter
    if (query.tier && query.tier !== 'All') {
        filters.push('customer_tier = ?');
        values.push(query.tier);
    }

    const whereClause = filters.length > 0 ? `WHERE ${filters.join(' AND ')}` : '';
    return { whereClause, values };
}

/**
 * Executes a simple query and returns the rows.
 */
async function runQuery(sql, values) {
    const [rows] = await db.execute(sql, values);
    return rows;
}


// =========================================================================
//                             DATA ENTRY ENDPOINT
// =========================================================================

app.post(`${BASE_API_PATH}/add-record`, async (req, res) => {
    try {
        const {
            order_date, revenue, product_name, product_category,
            customer_id, customer_tier, region, sales_channel, order_id
        } = req.body;
        
        // Basic validation
        if (!order_date || !revenue || !order_id) {
            return res.status(400).json({ message: 'Missing required fields: date, revenue, and order ID are mandatory.' });
        }

        const sql = `
            INSERT INTO sales_data 
            (order_date, revenue, product_name, product_category, customer_id, customer_tier, region, sales_channel, order_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        const values = [
            order_date, revenue, product_name, product_category,
            customer_id, customer_tier, region, sales_channel, order_id
        ];

        const [result] = await db.execute(sql, values);
        
        res.status(201).json({ 
            message: 'Record successfully added.', 
            id: result.insertId 
        });

    } catch (error) {
        console.error('Data Insertion Error:', error);
        
        let message = 'An unexpected server error occurred during data insertion.';
        
        if (error.code === 'ER_DUP_ENTRY') {
            message = `Error: Duplicate entry. The Order ID '${req.body.order_id}' already exists.`;
            return res.status(409).json({ message });
        }
        
        res.status(500).json({ message });
    }
});


// =========================================================================
//                             EXPORT ENDPOINT
// =========================================================================

app.get(`${BASE_API_PATH}/export`, async (req, res) => {
    try {
        const { whereClause, values } = buildFilter(req.query);

        // Fetch all relevant columns for a complete export
        const sql = `
            SELECT 
                order_id, order_date, region, product_name, 
                sales_channel, product_category, customer_tier, 
                revenue, customer_id
            FROM sales_data 
            ${whereClause} 
            ORDER BY order_date DESC
        `;
        
        const rows = await runQuery(sql, values);

        if (rows.length === 0) {
            return res.status(404).json({ 
                message: "No data found matching the current filters to export." 
            });
        }

        // Convert JSON rows to CSV string
        let csv;
        try {
            const json2csvParser = new Parser();
            csv = json2csvParser.parse(rows);
        } catch (err) {
            console.error('CSV Conversion Error:', err);
            throw new Error("Failed to convert data to CSV format.");
        }

        // Send the CSV file with correct headers
        const date = new Date().toISOString().slice(0, 10);
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="analytics_export_${date}.csv"`);
        
        res.status(200).send(csv);

    } catch (error) {
        // Sends a JSON error back to the client to avoid the HTML parsing error
        console.error('API Export Error:', error);
        res.status(500).json({ 
            message: error.message || "An unexpected server error occurred during export." 
        });
    }
});


// =========================================================================
//                             DASHBOARD READ ENDPOINTS
// =========================================================================

// --- /api/kpis (Includes AOV and Orders per Customer) ---
app.get(`${BASE_API_PATH}/kpis`, async (req, res) => {
    try {
        const { whereClause, values } = buildFilter(req.query);
        
        const sql = `
            SELECT 
                SUM(revenue) AS revenue,
                COUNT(DISTINCT customer_id) AS customers,
                COUNT(order_id) AS orders,
                SUM(revenue) / COUNT(order_id) AS aov,
                COUNT(order_id) / COUNT(DISTINCT customer_id) AS orders_per_customer
            FROM sales_data 
            ${whereClause}
        `;
        
        const kpiData = await runQuery(sql, values);

        // Safely access data, defaulting to empty object if no row is returned
        const dataRow = kpiData && kpiData.length > 0 ? kpiData[0] : {};

        const revenue = dataRow.revenue || 0;
        const customers = dataRow.customers || 0;
        const orders = dataRow.orders || 0;
        const aov = dataRow.aov || 0;
        const orders_per_customer = dataRow.orders_per_customer || 0;
        
        // Mocked growth calculation (kept for consistency with the frontend KPI card)
        const growth = revenue > 1000000 ? 15.2 : (revenue > 0 ? 5.8 : 0); 

        res.json({
            revenue: revenue,
            customers: customers,
            orders: orders,
            growth: growth.toFixed(1),
            aov: aov,
            orders_per_customer: orders_per_customer
        });
    } catch (error) {
        console.error('KPIs API Error:', error);
        res.status(500).json({ message: 'Error fetching KPIs.' });
    }
});


// --- /api/sales (Monthly trend) ---
app.get(`${BASE_API_PATH}/sales`, async (req, res) => {
    try {
        const { whereClause, values } = buildFilter(req.query);
        
        const sql = `
            SELECT 
                DATE_FORMAT(order_date, '%Y-%m') as label, 
                SUM(revenue) as data
            FROM sales_data
            ${whereClause}
            GROUP BY label
            ORDER BY label ASC
        `;
        
        const rows = await runQuery(sql, values);
        
        res.json({
            labels: rows.map(r => r.label),
            data: rows.map(r => r.data)
        });
    } catch (error) {
        console.error('Sales API Error:', error);
        res.status(500).json({ message: 'Error fetching sales trend.' });
    }
});


// --- /api/categories (NEW: Revenue by Product Category for Pie Chart) ---
app.get(`${BASE_API_PATH}/categories`, async (req, res) => {
    try {
        const { whereClause, values } = buildFilter(req.query);
        
        const sql = `
            SELECT 
                product_category as label, 
                SUM(revenue) as data
            FROM sales_data
            ${whereClause}
            GROUP BY product_category
            ORDER BY data DESC
        `;
        
        const rows = await runQuery(sql, values);
        
        res.json({
            labels: rows.map(r => r.label),
            data: rows.map(r => r.data)
        });
    } catch (error) {
        console.error('Categories API Error:', error);
        res.status(500).json({ message: 'Error fetching categories.' });
    }
});


// --- /api/channel-aov (NEW: AOV by Sales Channel for Bar Chart) ---
app.get(`${BASE_API_PATH}/channel-aov`, async (req, res) => {
    try {
        const { whereClause, values } = buildFilter(req.query);
        
        const sql = `
            SELECT 
                sales_channel as label, 
                SUM(revenue) / COUNT(order_id) as data
            FROM sales_data
            ${whereClause}
            GROUP BY sales_channel
            ORDER BY data DESC
        `;
        
        const rows = await runQuery(sql, values);
        
        res.json({
            labels: rows.map(r => r.label),
            data: rows.map(r => r.data)
        });
    } catch (error) {
        console.error('Channel AOV API Error:', error);
        res.status(500).json({ message: 'Error fetching channel AOV.' });
    }
});

// --- /api/tier-count (NEW: Customer Count by Tier for Doughnut Chart) ---
app.get(`${BASE_API_PATH}/tier-count`, async (req, res) => {
    try {
        const { whereClause, values } = buildFilter(req.query);
        
        const sql = `
            SELECT 
                customer_tier as label, 
                COUNT(DISTINCT customer_id) as data
            FROM sales_data
            ${whereClause}
            GROUP BY customer_tier
            ORDER BY data DESC
        `;
        
        const rows = await runQuery(sql, values);
        
        res.json({
            labels: rows.map(r => r.label),
            data: rows.map(r => r.data)
        });
    } catch (error) {
        console.error('Tier Count API Error:', error);
        res.status(500).json({ message: 'Error fetching tier count.' });
    }
});


// --- /api/products (Top 5 Products - UNCHANGED) ---
app.get(`${BASE_API_PATH}/products`, async (req, res) => {
    try {
        const { whereClause, values } = buildFilter(req.query);
        
        const sql = `
            SELECT 
                product_name as label, 
                SUM(revenue) as data
            FROM sales_data
            ${whereClause}
            GROUP BY product_name
            ORDER BY data DESC
            LIMIT 5
        `;
        
        const rows = await runQuery(sql, values);
        
        res.json({
            labels: rows.map(r => r.label),
            data: rows.map(r => r.data)
        });
    } catch (error) {
        console.error(`Products API Error:`, error);
        res.status(500).json({ message: `Error fetching products.` });
    }
});


// --- /api/regions (Kept only for filter dropdown options) ---
app.get(`${BASE_API_PATH}/regions`, async (req, res) => {
    try {
        const { whereClause, values } = buildFilter(req.query);
        
        const sql = `
            SELECT 
                region as label, 
                SUM(revenue) as data
            FROM sales_data
            ${whereClause}
            GROUP BY region
            ORDER BY data DESC
        `;
        
        const rows = await runQuery(sql, values);
        
        res.json({
            labels: rows.map(r => r.label),
            data: rows.map(r => r.data)
        });
    } catch (error) {
        console.error(`Regions API Error:`, error);
        res.status(500).json({ message: `Error fetching regions.` });
    }
});


// --- /api/metadata (Filter Options) ---
app.get(`${BASE_API_PATH}/metadata`, async (req, res) => {
    try {
        const [regions] = await db.query('SELECT DISTINCT region FROM sales_data ORDER BY region');
        const [products] = await db.query('SELECT DISTINCT product_name FROM sales_data ORDER BY product_name LIMIT 100');
        const [channels] = await db.query('SELECT DISTINCT sales_channel FROM sales_data ORDER BY sales_channel');
        const [categories] = await db.query('SELECT DISTINCT product_category FROM sales_data ORDER BY product_category');

        res.json({
            regions: regions.map(r => r.region),
            products: products.map(r => r.product_name),
            channels: channels.map(r => r.sales_channel),
            categories: categories.map(r => r.product_category)
        });
    } catch (error) {
        console.error('Metadata API Error:', error);
        res.status(500).json({ message: 'Error fetching metadata.' });
    }
});


// --- Server Startup ---
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Access dashboard at: http://localhost:${PORT}/`);
});